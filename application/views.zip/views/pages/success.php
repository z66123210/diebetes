<div class="main">
A new page has been added.
 </div>