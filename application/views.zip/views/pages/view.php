<?php
echo '<h2> Title'.$pages_item['Title'].'</h2>'; 
echo '<br /> <p> User ID: '.$pages_item['UserId'];
echo '<br /> <p> Body: '.$pages_item['Body'];
echo '<br /> <p> Image: '.$pages_item['Image']. '<br />';
?>